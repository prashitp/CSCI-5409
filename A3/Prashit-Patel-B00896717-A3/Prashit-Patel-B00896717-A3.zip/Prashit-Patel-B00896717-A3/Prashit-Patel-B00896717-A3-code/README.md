- References
[1]“secrets_getsecretvalue.js - AWS Code Sample,” Amazon.com, 2019. https://docs.aws.amazon.com/code-samples/latest/catalog/javascript-secrets-secrets_getsecretvalue.js.html (accessed Mar. 25, 2022).
‌
[2]insoftservice, “Retrieve secrets from AWS Secrets Manager in Node.js,” Stack Overflow, Aug. 30, 2021. https://stackoverflow.com/questions/68980785/retrieve-secrets-from-aws-secrets-manager-in-node-js (accessed Mar. 25, 2022).

[3]Z. Geer, “How to Build a CRUD Application Using Node.js and MySQL?,” Medium, May 21, 2019. https://medium.com/edureka/node-js-mysql-tutorial-cef7452f2762 (accessed Mar. 25, 2022).
‌
[4]Titetili, “How to display a variable in html generated with node.js,” Stack Overflow, Apr. 25, 2019. https://stackoverflow.com/questions/55848247/how-to-display-a-variable-in-html-generated-with-node-js (accessed Mar. 25, 2022).
‌
[5]“Tutorial: Create an Amazon VPC for use with a DB instance - Amazon Relational Database Service,” Amazon.com, 2022. https://docs.aws.amazon.com/AmazonRDS/latest/UserGuide/CHAP_Tutorials.WebServerDB.CreateVPC.html (accessed Mar. 25, 2022).

[6]“Connecting to a DB instance running the MySQL database engine - Amazon Relational Database Service,” Amazon.com, 2022. https://docs.aws.amazon.com/AmazonRDS/latest/UserGuide/USER_ConnectToInstance.html (accessed Mar. 25, 2022).