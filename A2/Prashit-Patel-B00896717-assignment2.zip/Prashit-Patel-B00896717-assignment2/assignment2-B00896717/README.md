- References
[1] “Loading Credentials in Node.js from a JSON File - AWS SDK for JavaScript,” Amazon.com, 2022. https://docs.aws.amazon.com/sdk-for-javascript/v2/developer-guide/loading-node-credentials-json-file.html (accessed Mar. 02, 2022).

[2] “Class: AWS.S3 — AWS SDK for JavaScript,” Amazon.com, 2022. https://docs.aws.amazon.com/AWSJavaScriptSDK/latest/AWS/S3.html#upload-property (accessed Mar. 02, 2022).
‌

‌